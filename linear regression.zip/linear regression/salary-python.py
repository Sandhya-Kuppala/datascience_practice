# salary hike
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import statsmodels.formula.api as smf

df=pd.read_csv('Salary_data.csv')
df.head()
df.columns = ('experience','salary')

#Graphical Representation
#plt.bar(height = df.weight,x = np.arange(1, 1000, 1))
plt.hist(df.salary)
plt.boxplot(df.salary)

#plt.bar(height = wcat.Waist, x = np.arange(1, 110, 1))
plt.hist(df.experience) 
plt.boxplot(df.experience) 

# Scatter plot
plt.scatter(x = df['experience'], y = df['salary'], color = 'green') 

# correlation
np.corrcoef(df.experience, df.salary) 

# Simple Linear Regression
model = smf.ols('salary ~ experience', data = df).fit()
model.summary()

pred1 = model.predict(pd.DataFrame(df['experience']))

# Regression Line
plt.scatter(df.experience,df.salary)
plt.plot(df.experience, pred1, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res1 = df.salary - pred1
res_sqr1 = res1 * res1
mse1 = np.mean(res_sqr1)
rmse1 = np.sqrt(mse1)
rmse1


