# delivery time
library(Hmisc)
library("lattice")

df <- read.csv(file.choose())
head(df)
colnames(df) <- c('delivery','sort')

# Graphical exploration
dotplot(df$delivery,main="Dotplot for delivery gained")
dotplot(df$sort,main="Dotplot for sort consumed")

#boxplot
boxplot(df$delivery,col = "dodgerblue2",horizontal = T)
boxplot(df$sort, col = "red4", horizontal = T)

#histogram
hist(df$delivery,col='dodgerblue2')
hist(df$sort,col='red4')


# Normal QQ plot
#delivery
qqnorm(df$delivery,col='dodgerblue2')
qqline(df$delivery,col='green4')
#sort
qqnorm(df$sort,col='red4')
qqline(df$sort,col='green4')

hist(df$delivery, prob = TRUE,col = 'dodgerblue2')     
lines(density(df$delivery),col='red4')        
lines(density(df$delivery, adjust = 2), lty = "dotted",col='green4')

hist(df$sort, prob = TRUE,col = 'green')     
lines(density(df$sort),col='red4')        
lines(density(df$sort, adjust = 2), lty = "dotted",col='blue')

# Bivariate analysis
# Scatter plot
plot(df$sort, df$delivery, main = "Scatter Plot", col = "red4", 
     col.main = "Dodgerblue4", col.lab = "Dodgerblue4", xlab = "sort consumed", 
     ylab = "delivery gained", pch = 20)  

attach(df)

# Correlation Coefficient
cor(sort, delivery)

# Covariance
cov(sort, delivery)
# Linear Regression model
reg <- lm(delivery ~ sort, data = df)
summary(reg)
confint(reg, level = 0.95)

pred <- predict(reg, interval = "predict")
pred <- as.data.frame(pred)
View(pred)
# ggplot for adding Regression line for data
library(ggplot2)

ggplot(data = df, aes(sort, delivery) ) +
  geom_point(color = 'red') + stat_smooth(method = lm, formula = y ~ x)


# Evaluation the model for fitness 
cor(pred$fit, df$delivery)
#
#library(mvinfluence)

