# calories consumed
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import statsmodels.formula.api as smf

df=pd.read_csv('delivery_time.csv')
df.head()
df.columns = ('delivery','sort')

#Graphical Representation
#plt.bar(height = df.weight,x = np.arange(1, 1000, 1))
plt.hist(df.delivery)
plt.boxplot(df.delivery)

#plt.bar(height = wcat.Waist, x = np.arange(1, 110, 1))
plt.hist(df.sort) 
plt.boxplot(df.sort) 

# Scatter plot
plt.scatter(x = df['sort'], y = df['delivery'], color = 'green') 

# correlation
np.corrcoef(df.sort, df.delivery) 

# Simple Linear Regression
model = smf.ols('delivery ~ sort', data = df).fit()
model.summary()

pred1 = model.predict(pd.DataFrame(df['sort']))

# Regression Line
plt.scatter(df.sort,df.delivery)
plt.plot(df.sort, pred1, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res1 = df.delivery - pred1
res_sqr1 = res1 * res1
mse1 = np.mean(res_sqr1)
rmse1 = np.sqrt(mse1)
rmse1
