# churn consumed
library(Hmisc)
library("lattice")

df <- read.csv(file.choose())
head(df)
colnames(df) <- c('salary','churn')

# Graphical exploration
dotplot(df$salary,main="Dotplot for salary gained")
dotplot(df$churn,main="Dotplot for churn consumed")

#boxplot
boxplot(df$salary,col = "dodgerblue2",horizontal = T)
boxplot(df$churn, col = "red4", horizontal = T)

#histogram
hist(df$salary,col='dodgerblue2')
hist(df$churn,col='red4')


# Normal QQ plot
#salary
qqnorm(df$salary,col='dodgerblue2')
qqline(df$salary,col='green4')
#churn
qqnorm(df$churn,col='red4')
qqline(df$churn,col='green4')

hist(df$salary, prob = TRUE,col = 'dodgerblue2')     
lines(density(df$salary),col='red4')        
lines(density(df$salary, adjust = 2), lty = "dotted",col='green4')

hist(df$churn, prob = TRUE,col = 'green')     
lines(density(df$churn),col='red4')        
lines(density(df$churn, adjust = 2), lty = "dotted",col='blue')

# Bivariate analysis
# Scatter plot
plot(df$churn, df$salary, main = "Scatter Plot", col = "red4", 
     col.main = "Dodgerblue4", col.lab = "Dodgerblue4", xlab = "churn consumed", 
     ylab = "salary gained", pch = 20)  

attach(df)

# Correlation Coefficient
cor(salary,churn)

# Covariance
cov(salary,churn)
# Linear Regression model
reg <- lm(churn ~ salary, data = df)
summary(reg)
confint(reg, level = 0.95)

pred <- predict(reg, interval = "predict")
pred <- as.data.frame(pred)
View(pred)
# ggplot for adding Regression line for data
library(ggplot2)

ggplot(data = df, aes(salary, churn) ) +
  geom_point(color = 'red') + stat_smooth(method = lm, formula = y ~ x)


# Evaluation the model for fitness 
cor(pred$fit, df$churn)

#Hence the P-value is less than 0.05. So X varibale is significance and also Multiple R-Square value is 0.8968. That's mean this model will predict the output 89.68% time correct
