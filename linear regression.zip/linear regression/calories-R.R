# calories consumed
library(Hmisc)
library("lattice")

df <- read.csv(file.choose())
head(df)
colnames(df) <- c('weight','calories')

# Graphical exploration
dotplot(df$weight,main="Dotplot for weight gained")
dotplot(df$calories,main="Dotplot for calories consumed")

#boxplot
boxplot(df$weight,col = "dodgerblue2",horizontal = T)
boxplot(df$calories, col = "red4", horizontal = T)

#histogram
hist(df$weight,col='dodgerblue2')
hist(df$calories,col='red4')


# Normal QQ plot
#weight
qqnorm(df$weight,col='dodgerblue2')
qqline(df$weight,col='green4')
#calories
qqnorm(df$calories,col='red4')
qqline(df$calories,col='green4')

hist(df$weight, prob = TRUE,col = 'dodgerblue2')     
lines(density(df$weight),col='red4')        
lines(density(df$weight, adjust = 2), lty = "dotted",col='green4')

hist(df$calories, prob = TRUE,col = 'green')     
lines(density(df$calories),col='red4')        
lines(density(df$calories, adjust = 2), lty = "dotted",col='blue')

# Bivariate analysis
# Scatter plot
plot(df$calories, df$weight, main = "Scatter Plot", col = "red4", 
     col.main = "Dodgerblue4", col.lab = "Dodgerblue4", xlab = "calories consumed", 
     ylab = "Weight gained", pch = 20)  

attach(df)

# Correlation Coefficient
cor(calories, weight)

# Covariance
cov(calories, weight)
# Linear Regression model
reg <- lm(weight ~ calories, data = df)
summary(reg)
confint(reg, level = 0.95)

pred <- predict(reg, interval = "predict")
pred <- as.data.frame(pred)
View(pred)
# ggplot for adding Regression line for data
library(ggplot2)

ggplot(data = df, aes(calories, weight) ) +
  geom_point(color = 'red') + stat_smooth(method = lm, formula = y ~ x)


# Evaluation the model for fitness 
cor(pred$fit, df$weight)

#Hence the P-value is less than 0.05. So X varibale is significance and also Multiple R-Square value is 0.8968. That's mean this model will predict the output 89.68% time correct
