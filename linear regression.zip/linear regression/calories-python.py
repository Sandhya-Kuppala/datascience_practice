# calories consumed
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import statsmodels.formula.api as smf

df=pd.read_csv('calories_consumed.csv')
df.head()
df.columns = ('weight','calories')

#Graphical Representation
#plt.bar(height = df.weight,x = np.arange(1, 1000, 1))
plt.hist(df.weight)
plt.boxplot(df.weight)

#plt.bar(height = wcat.Waist, x = np.arange(1, 110, 1))
plt.hist(df.calories) 
plt.boxplot(df.calories) 

# Scatter plot
plt.scatter(x = df['calories'], y = df['weight'], color = 'green') 

# correlation
np.corrcoef(df.calories, df.weight) 

# Simple Linear Regression
model = smf.ols('weight ~ calories', data = df).fit()
model.summary()

pred1 = model.predict(pd.DataFrame(df['calories']))

# Regression Line
plt.scatter(df.calories,df.weight)
plt.plot(df.calories, pred1, "r")
plt.legend(['Predicted line', 'Observed data'])
plt.show()

# Error calculation
res1 = df.weight - pred1
res_sqr1 = res1 * res1
mse1 = np.mean(res_sqr1)
rmse1 = np.sqrt(mse1)
rmse1
